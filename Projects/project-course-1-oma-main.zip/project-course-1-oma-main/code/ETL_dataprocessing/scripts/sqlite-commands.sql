.mode csv
.import /data/SensorData.csv SensorData
