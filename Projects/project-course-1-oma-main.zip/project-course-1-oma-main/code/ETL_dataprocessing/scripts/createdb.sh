#!/usr/bin/env bash
#cd /var/lib/mysql/iiwari_org
docker exec -i iiwari-mariadb-server /usr/bin/mysql -u root --password=d41k4Duu
